# Notify Comment on Commented #

### About ###
Notifies if someone has commented on a disicussion the user has commented on.

In conf/config.php you can set the defaults like so:

    $Configuration['Preferences']['Email']['CommentOnCommented'] = '1';
    $Configuration['Preferences']['Popup']['CommentOnCommented'] = '1';

### Sponsor ###
Special thanks to balaboostas.com for making this happen.

